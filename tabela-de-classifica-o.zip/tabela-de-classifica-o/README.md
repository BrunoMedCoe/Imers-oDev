# Tabela de classificação

A Pen created on CodePen.io. Original URL: [https://codepen.io/BrunoCoelhom/pen/XWVJyVO](https://codepen.io/BrunoCoelhom/pen/XWVJyVO).

